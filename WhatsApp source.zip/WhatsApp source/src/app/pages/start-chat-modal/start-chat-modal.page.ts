import { Component, OnInit, ViewChildren, ElementRef, QueryList } from '@angular/core';
import contactData from '../../../assets/data/contacts.json';
import { IonItemGroup, ModalController } from '@ionic/angular';

@Component({
  selector: 'app-start-chat-modal',
  templateUrl: './start-chat-modal.page.html',
  styleUrls: ['./start-chat-modal.page.scss'],
})
export class StartChatModalPage implements OnInit {
  contacts = [];

  constructor(private modalCtrl: ModalController) { }

  ngOnInit() {
    const sorted = contactData.sort((a, b) => {
      if (a.last_name < b.last_name) { return -1; }
      if (a.last_name > b.last_name) { return 1; }
      return 0;
    });

    let last = null;
    for (let i  = 0; i < sorted.length; i++) {
      const contact = sorted[i];
      
      if (!last || last != contact.last_name[0]) {
        last = contact.last_name[0];
        this.contacts.push({key: last, contacts: []});
      }
      this.contacts[this.contacts.length - 1].contacts.push(contact);
    }    
  }

  close() {
    this.modalCtrl.dismiss();
  }

  @ViewChildren(IonItemGroup, { read: ElementRef }) itemGroups: QueryList<any>;
  scroll = true;

  scrollToLetter(letter) {
    // console.log('scroll: ', letter);
    for (let i = 0; i < this.contacts.length; i++) {
      const group = this.contacts[i];
      if (group.key == letter) {
        const group = this.itemGroups.filter((element, index) => index === i);
        if (group) {
          const el: any = group[0];
          console.log(el);
          el.nativeElement.scrollIntoView();
        }        
        return;
      }
    }
  }

  letterScrollActive(active) {
    this.scroll = active;
  }
}

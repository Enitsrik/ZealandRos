import {
  Component,
  OnInit,
  ViewChild,
  ViewChildren,
  ElementRef,
  QueryList,
  AfterViewInit,
  ChangeDetectorRef,
} from '@angular/core';
import {
  IonContent,
  GestureController,
  IonTextarea,
  Platform,
} from '@ionic/angular';
import msgData from '../../../assets/data/msg.json';
import { Haptics, ImpactStyle } from '@capacitor/haptics';
import { Keyboard, KeyboardResize } from '@capacitor/keyboard';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.page.html',
  styleUrls: ['./chat.page.scss'],
})
export class ChatPage implements OnInit, AfterViewInit {
  @ViewChild(IonContent) content: IonContent;
  @ViewChildren('messagecols', { read: ElementRef })
  messagCols: QueryList<ElementRef>;

  @ViewChild('msginput') msginput: IonTextarea;
  @ViewChild('footer', { read: ElementRef }) footer: ElementRef;
  scrollPercentage = 0;
  info = msgData;
  currentUserId = 0;
  replyMsg = null;

  constructor(
    private gestureCtrl: GestureController,
    private plt: Platform,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit() {
    setTimeout(() => {
      this.content.scrollToBottom(400);
    }, 300);
  }

  ngAfterViewInit() {
    this.messagCols.forEach((elem, index) => {
      this.addSwipeGesture(elem, index);
    });

    if (this.plt.is('ios')) {
      Keyboard.setResizeMode({ mode: KeyboardResize.None });

      Keyboard.addListener('keyboardWillShow', async (ev) => {
        const { keyboardHeight } = ev;

        this.footer.nativeElement.style.setProperty(
          'transform',
          `translateY(-${keyboardHeight - 30}px)`
        );

        this.footer.nativeElement.style.setProperty(
          'transition',
          '.25s ease-out'
        );
      });

      Keyboard.addListener('keyboardWillHide', () => {
        this.footer.nativeElement.style.removeProperty('transform');
      });
    }
  }

  addSwipeGesture(el, msgIndex) {
    const style = el.nativeElement.style;
    const circle = el.nativeElement.children[0];
    let didVibrate = false;

    const swipeGesture = this.gestureCtrl.create(
      {
        gestureName: `swipe-${msgIndex}`,
        el: el.nativeElement,
        direction: 'x',
        threshold: 10,
        passive: true,
        onMove: (ev) => {
          const deltaX = ev.deltaX;
          const circleOpacity = Math.max(0, ev.deltaX / 130);

          circle.style.opacity = circleOpacity;

          if (deltaX > 0) {
            el.nativeElement.style.transform = `translateX(${deltaX}px)`;
          }

          if (ev.deltaX > 130 && !didVibrate) {
            Haptics.impact({ style: ImpactStyle.Light });
            didVibrate = true;
          }
        },
        onEnd: (ev) => {
          didVibrate = false;
          style.transition = '0.2s ease-out';

          style.transform = '';
          circle.style.transition = style.transition;
          circle.style.opacity = 0;

          if (ev.deltaX > 130) {
            this.triggerReply(msgIndex);
          }
        },
      },
      true
    ); // Add to run inside Angular zone detection

    // Don't forget to enable!
    swipeGesture.enable(true);
  }

  triggerReply(msgIndex) {
    this.replyMsg = this.info.msgs[msgIndex];
    this.msginput.setFocus();
  }

  closeReply() {
    this.replyMsg = null;
  }

  async contentScrolled(ev) {
    const scrollElement = await this.content.getScrollElement();
    const scrollPosition = ev.detail.scrollTop;
    const totalContentHeight = scrollElement.scrollHeight;

    this.scrollPercentage =
      scrollPosition / (totalContentHeight - ev.target.clientHeight) + 0.001;
    this.changeDetectorRef.detectChanges();
  }

  scrollDown() {
    this.content.scrollToBottom(300);
  }
}

import { Component, OnInit, ViewChild } from '@angular/core';
import { IonTabs } from '@ionic/angular';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.page.html',
  styleUrls: ['./tabs.page.scss'],
})
export class TabsPage implements OnInit {
  @ViewChild(IonTabs) tabs: IonTabs;
  selected = 'chats';
  cameraActive = false;

  constructor() { }

  ngOnInit() { }

  setSelectedTab() {
    console.log('tab changed!');
    
    setTimeout(() => {

      this.selected = this.tabs.getSelected();
      console.log('selected now: ', this.selected);
      this.cameraActive = this.selected == 'camera';

    })
    
  }
}
